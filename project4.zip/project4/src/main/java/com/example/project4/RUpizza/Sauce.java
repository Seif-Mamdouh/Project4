package com.example.project4.RUpizza;

public enum Sauce {
    TOMATO, ALFREDO
}
